// ===========================================
// TurtleBot3 AI Assistant
// script.js
// ===========================================

// ----------------------------
// WebSocket 연결
// ----------------------------

const ws = new WebSocket("ws://" + location.host + "/ws");

// ----------------------------
// HTML 요소
// ----------------------------

const connection = document.getElementById("connection");
const robotState = document.getElementById("robotState");
const voiceText = document.getElementById("voiceText");
const aiText = document.getElementById("aiText");
const logBox = document.getElementById("logBox");

const btnForward = document.getElementById("forward");
const btnBackward = document.getElementById("backward");
const btnLeft = document.getElementById("left");
const btnRight = document.getElementById("right");
const btnStop = document.getElementById("stop");

const btnEmergency = document.getElementById("emergency");
const btnRelease = document.getElementById("release");

// ----------------------------
// 로그 출력
// ----------------------------

function addLog(text){

    const now = new Date();

    const time =
        now.getHours().toString().padStart(2,"0") + ":" +
        now.getMinutes().toString().padStart(2,"0") + ":" +
        now.getSeconds().toString().padStart(2,"0");

    const div = document.createElement("div");

    div.className = "log-item";

    div.innerHTML = "[" + time + "] " + text;

    logBox.prepend(div);

}

// ----------------------------
// JSON 전송
// ----------------------------

function sendJSON(data){

    if(ws.readyState === WebSocket.OPEN){

        ws.send(JSON.stringify(data));

    }

}

// ----------------------------
// WebSocket 연결
// ----------------------------

ws.onopen = ()=>{

    connection.innerHTML="🟢 Connected";

    addLog("Connected");

};

ws.onclose = ()=>{

    connection.innerHTML="🔴 Disconnected";

    addLog("Disconnected");

};

// ----------------------------
// 서버 메시지
// ----------------------------

ws.onmessage = (event)=>{

    const msg = JSON.parse(event.data);

    console.log(msg);

    if(msg.type==="status"){

        if(msg.robot_state){

            robotState.innerHTML = msg.robot_state;

        }

        if(msg.message){

            addLog(msg.message);

        }

    }

    else if(msg.type==="voice"){

        if(msg.stt){

            voiceText.innerHTML = msg.stt;

        }

        if(msg.ai){

            aiText.innerHTML = msg.ai;

        }

        addLog("Voice : " + msg.stt);

    }

    else if(msg.type==="error"){

        addLog("ERROR : " + msg.message);

    }

};

// ----------------------------
// 이동 명령
// ----------------------------

function control(command){

    sendJSON({

        type:"control",

        command:command

    });

}

// ----------------------------
// 버튼 길게 누르기
// ----------------------------

function holdButton(button,command){

    function start(e){

        e.preventDefault();

        control(command);

    }

    function stop(e){

        e.preventDefault();

        control("stop");

    }

    button.addEventListener("mousedown",start);

    button.addEventListener("mouseup",stop);

    button.addEventListener("mouseleave",stop);

    button.addEventListener("touchstart",start,{passive:false});

    button.addEventListener("touchend",stop);

}

// ----------------------------

holdButton(btnForward,"forward");

holdButton(btnBackward,"backward");

holdButton(btnLeft,"left");

holdButton(btnRight,"right");

// ----------------------------
// Stop 버튼
// ----------------------------

btnStop.onclick=()=>{

    control("stop");

};

// ----------------------------
// Emergency
// ----------------------------

btnEmergency.onclick=()=>{

    sendJSON({

        type:"emergency"

    });

};

// ----------------------------
// Emergency Release
// ----------------------------

btnRelease.onclick=()=>{

    sendJSON({

        type:"release"

    });

};

// ----------------------------
// 서버 연결 후 상태 요청
// ----------------------------

ws.addEventListener("open",()=>{

    sendJSON({

        type:"status"

    });

});
