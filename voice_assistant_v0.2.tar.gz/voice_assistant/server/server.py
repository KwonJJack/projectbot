#!/usr/bin/env python3

import json
import threading
from pathlib import Path

import rclpy

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

from ros_node import WebControlNode
from message import MessageRouter

# --------------------------------------------------
# ROS2 초기화
# --------------------------------------------------

rclpy.init()

ros_node = WebControlNode()


def ros_spin():
    rclpy.spin(ros_node)


threading.Thread(
    target=ros_spin,
    daemon=True
).start()

# --------------------------------------------------
# FastAPI
# --------------------------------------------------

app = FastAPI(title="TurtleBot3 AI Assistant")

BASE_DIR = Path(__file__).resolve().parent.parent
WEB_DIR = BASE_DIR / "web"

app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")

router = MessageRouter(ros_node)

clients = []


@app.get("/")
async def root():
    return FileResponse(WEB_DIR / "index.html")


# --------------------------------------------------
# WebSocket
# --------------------------------------------------

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):

    await ws.accept()

    clients.append(ws)

    print("Client Connected")

    await ws.send_json({
        "type": "status",
        "connected": True,
        "robot_state": "IDLE",
        "ai": "대기중",
        "stt": ""
    })

    try:

        while True:

            data = await ws.receive_text()

            try:

                message = json.loads(data)

            except json.JSONDecodeError:

                await ws.send_json({
                    "type": "error",
                    "message": "JSON Parse Error"
                })

                continue

            response = router.handle(message)

            if response is not None:
                await ws.send_json(response)

    except WebSocketDisconnect:

        print("Client Disconnected")

        if ws in clients:
            clients.remove(ws)


# --------------------------------------------------

if __name__ == "__main__":

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000
    )
